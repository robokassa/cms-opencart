<?php
// Text
$_['text_title']       = 'Робокасса <img src="image/payment/robokassa.png" alt="" style="max-width: 150px;">';
$_['text_description']       = 'Робокасса <img src="image/payment/robokassa.png" alt="" style="max-width: 150px;">';