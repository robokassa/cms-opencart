<?php
// Text
$_['text_title']       = 'Робокака <img src="image/payment/robokassa.png" alt="" style="max-width: 150px;">';
$_['text_description']       = 'Робокака <img src="image/payment/robokassa.png" alt="" style="max-width: 150px;">';